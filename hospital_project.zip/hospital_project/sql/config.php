<?php

$host = 'localhost';
$username = 'root';
$password = '';
$dbname  = 'medicare';


$conn = mysqli_connect($host , $username , $password , $dbname);

if(!$conn){
	echo "error" .mysqli_error($conn);
}

?>