<?php
if(isset($_POST['submit'])){

	include 'config.php';


	$name = $_POST['name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$date = $_POST['date'];
	$message = $_POST['message'];

	$sql = "INSERT INTO appoint(name ,email,phone,date,message)VALUES('$name','$email','$phone','$date','$message')";

	if(mysqli_query($conn,$sql)){

		$_SESSION['msg'] = 'Successfully Booking';
		
		header('location:http://localhost/hospital_project/');
		exit();

	}else{
		echo "error" .mysqli_error($conn);
	}

}


?>