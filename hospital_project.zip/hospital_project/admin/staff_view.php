<?php
include 'include/header.php';
include 'include/sidebar.php';
include  'include/top-header.php';
?>

<style>
    
        body {
            background-color: #F1F4F5;
        }
        
        .card-header {
            padding: 0.2rem 1.25rem;
            background-color: #ffffff;
            border-bottom: 0px;
        }
        
        .card-body {
            padding: 0rem 1.25rem;
        }
        
        p {
            margin-top: 0;
            margin-bottom: 10px;
        }
        
        .card {
            border-radius: 0px;
            padding-top: 15px;
            padding-bottom: 15px;
        }
        

</style>

<div class="container">
	<div class="row mt-5">
		<div class="col-12 col-md-12">
            <div class="pb-4">
                <a href="index.php"> Home <i class=" fas fa-angle-right"></i> <a href="#"> Doctor's View</a> </a>
            </div>
		 
				<form>
					<div class="col-md-12">
                <div class="card">

                <div class="card-header">
                    <h4>Data Table Export</h4>
                    <p>Data table with print, pdf, csv</p>
                </div>

                <div class="card-body">

                    <table class="table table-bordered table-hover" id="table_id">
                        <thead>
                            <tr>
                                <th>Sno.</th>
                                <th>Staff Name</th>
                                <th>Staff Exp</th>
    							<th>Phone </th>
                                 <th>Staff Image</th>
    							 <th>Action</th>

                            </tr>
                        </thead>
                        <tbody>

                            <?php
                            include 'sql/config.php';
                            ?>
                            <?php

                            $sql = "SELECT * FROM add_staff";

                            $table = mysqli_query($conn,$sql);
                            $i = 1;
                            if(mysqli_num_rows($table)>0){
                                while($row = mysqli_fetch_array($table)){
                                ?>
                                <tr>
                                    <?php


                                    ?>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo $row['sname']; ?></td>
                                    <td><?php echo $row['experiences_']; ?></td>
                                    <td><?php echo $row['phone_']; ?></td>

                                     <td style="padding-top: 40px;"><img src="./img/<?php echo $row['pic_'];?>" class="img-thumbnail" height="80px" width="70px"></td>
                                    
                                     <td>
                                    <a href="edit_staff.php?id=<?php echo $row['id'];?>" class="badge badge-primary">Edit</a>
                                    <a href="sql/staf_del.php?id=<?php echo $row['id'];?>" class="badge badge-danger">Delete</a> 
                    </td>
                                </tr>
                             <?php
                         $i++;
                    }
                }   

            ?>

                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="col-12 col-md-2"></div>
</div>
</div>

<?php
include 'include/footer.php';

?>