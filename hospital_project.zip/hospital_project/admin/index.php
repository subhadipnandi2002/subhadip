<?php


include 'include/header.php';
include 'include/sidebar.php';
include  'include/top-header.php';
?>
<style>

.card-area .card{
	height: 100px;
	box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
	border-left: 4px solid #277BC0;
	border-radius: 7px;
}
.main{
	height: 100px;
	width: 100%;
}
.main .ico-area{
	height: 100px;
	width: 40%;
	float: left;
}
.main .contant-area{
	width: 60%;
	height: 100px;
	float: left;
}

.main .contant-area p{
	color: #277BC0;
	font-size: 17px;
	padding-top: 50px!important;
	
}
.main .contant-area h4{
	padding-left: 60px;
}
.ico-area i{
	float: right;
	padding-right: 23px;
	padding-top: 27px;
	font-size: 35px;
	color: #277BC0;
}

</style>

<div class="container-fluid mt-4 m-0 p-0 card-top">
	<div class="row das-area">
		<div class="col-md-12 col-sm-12">
			<a href="#" style="margin-left: -0px!important;"> Dashboard</a>
		</div>
	</div>
	
	<div class="row card-area mt-4">
		<div class="col-12 col-md-3">
			<div class="card">
				<div class="main">
					<div class="contant-area">
						<p>Service</p>
						<h4 class="pt-5">20</h4>
					</div>
					<div class="ico-area">
						<i class="fas fa-concierge-bell"></i>
					</div>
				</div>
			</div>
		</div>
		<div class="col-12 col-md-3">
			<div class="card" >
				<div class="main">
					<div class="contant-area">
						<p>Booking</p>
						<h4 class="pt-5">200</h4>
					</div>
					<div class="ico-area">
						<i class="fas fa-book-reader"></i>
					</div>
				</div>
			</div>
		</div>
		<div class="col-12 col-md-3">
			<div class="card">
				<div class="main">
					<div class="contant-area">
						<p>Feedback</p>
						<h4 class="pt-5"> 50%</h4>

					</div>
					<div class="ico-area">
						<i class="fas fa-grin-stars"></i>
					</div>
				</div>
			</div>
		</div>
		<div class="col-12 col-md-3">
			<div class="card">
				<div class="main">
					<div class="contant-area">
						<p>Rating</p>
						<h4 class="pt-5">70% </h4>
					</div>
					<div class="ico-area">
						<i class="far fa-star"></i>
					</div>
				</div>
			</div>
		</div>
</div>



<?php
include 'include/footer.php';

?>