<style>
	#bars{
	float: right;
	color: #fff;
	display: none;
}
@media(max-width: 600px){
	#bars{
		display: block;
		padding: 8px 10px 8px 10px;
		border:1px solid #eee;
		border-radius: 80px;
		font-size: 24px;
		margin-top: 3px;
		margin-bottom: 3px;
	}
	#side{
		display: none;
	}
	.top_area-left{
		height: auto;
	}
}

</style>

<div class="row">
			<div class="col-md-2 col-sm-12 top_area-left">
				<div class="top-under">
					<h2 class="pt-3 pb-4" style="text-align: center; color: yellow;">nightingle hospital</h2>
				</div>
				<span onclick="Shownav()"><i class="fas fa-bars" id="bars"></i></span>

				<div id="side">
					<nav>
						<a href="#" style="border-bottom: 1px solid #eee;"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
						<a href="index.php" onclick="Show()"> <i class="fas fa-home"></i> Home <i class="fas fa-angle-right" id="drop1"></i></a>

						<a href="javascript:void()" onclick="Show1()"><i class="fas fa-ban"></i> Doctor<i class="fas fa-angle-right" id="drop2"></i></a>

						<div id="submenu2">
							<a href="add_doctor.php"> <i class="fas fa-plus-circle"></i> Add</a>
							<a href="doctor_view.php"><i class="fas fa-eye"></i> View</a>
						</div>


						<a href="javascript:void()" onclick="Show4()"><i class="fas fa-ban"></i> Staff<i class="fas fa-angle-right" id="drop2"></i></a>

						<div id="submenu5">
							<a href="add_staff.php"> <i class="fas fa-plus-circle"></i> Add</a>
							<a href="staff_view.php"><i class="fas fa-eye"></i> View</a>
						</div>


						<a href="javascript:void()" onclick="Show3()"><i class="fas fa-ban"></i> appointment<i class="fas fa-angle-right" id="drop2"></i></a>

						<div id="submenu4">
							<a href="appointment_view.php"><i class="fas fa-eye"></i> View</a>
						</div>
					</nav>
					
				</div>
			</div>