<div class="col-md-10 col-sm-12 top-body">
				<div>
					<form>
						<input type="text" name="name" class="form-control" id="box" placeholder="Search..." >
						<!-- <i class="fas fa-search"></i> -->
					</form>
					<img src="img/user.png" alt="..." height="35px" width="35px;">
					<p>User</p>
					<div class="icon-area">
						<i class="fas fa-bell" style="padding-right: 10px;"></i>
						<i class="fas fa-envelope"></i>
					</div>
				</div>
			