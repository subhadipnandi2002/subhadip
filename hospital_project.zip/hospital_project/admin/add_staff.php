<?php
include 'include/header.php';
include 'include/sidebar.php';
include  'include/top-header.php';
?>


<style>
	.add-area .card{
		height: auto;
	}
	.card h4{
		height: 50px;
		background-color: #eee;
		box-shadow: rgba(17, 17, 26, 0.1) 0px 1px 0px;
	}
	table tr td input[type="text"], [type="number"],[type="file"]{
		width: 370px;
		margin-top: 7px;
	}
	table tr td input[type="file"]{
		width: 370px;
		margin-top: 7px;
	}
	table tr th{
		margin-left: 10px!important  	;
	}
	#from{
		padding-left: 30px;
	}
	@media(max-width:600px){
		table tr th{
			padding-left: 30px!important;
		}
		table tr td input[type="text"]{
			margin-left: 30px;
		}
		.btn{
			margin-bottom: 15px;
			padding-bottom: 40px;
		}
	}
	
</style>

<div class="container">
	<div class="row mt-5">
		<div class="col-md-12 col-sm-12 add-area">
			<div class="pb-4">
				<a href="index.php"> Home <i class=" fas fa-angle-right"></i> <a href="#">Add Staff</a></a>
			</div>
			<div class="card mt-3">
				<h4 class="text-center pt-2">Add Staff's</h4>
				<form action="sql/insert_staff.php" method="POST" enctype="multipart/form-data">
				<div class="row">
					<div class="col-12 col-md-6">	
						<table>
						<tr>
							<th id="from">Staff Name</th>
						</tr>
						<tr>
							<td><input type="text" name="sname" class="form-control" style="margin-left: 30px;"></td>
						</tr>
					</table>
					</div>

					<div class="col-md-6 col-sm-12">
							<table>
						<tr>
							<th id="from">Staff Exprience</th>
						</tr>
						<tr>
							<td><input type="number" name="experiences_" class="form-control" style="margin-left: 30px;"></td>
						</tr>
					</table>
					</div>
				</div>
					<div class="row mt-3 ">
						
						<div class="col-12 col-md-6">	
						<table>
						<tr>
							<th id="from">Staff Number</th>
						</tr>
						<tr>
							<td><input type="number" name="phone_" class="form-control" style="margin-left: 30px;"></td>
						</tr>
					</table>
						
					</div>
					<div class="col-12 col-md-6 pl-5">	
						<table>
						<tr>
							<th>Staff Image</th>
						</tr>
						<tr>
							<td><input type="file" name="pic_" class="form-control"></td>
						</tr>
					</table>
					
					</div>
					
				</div>
				<div class="row">
					<div class="col-md-12 col-sm-12">
						<table>
							<input type="submit" name="submit" value="Submit" class="btn btn-primary ml-4 mt-4 pl-3 pr-3 mb-3">
						</table>
					</div>
				</div>
				
				</form>
			</div>
		</div>
	</div>
</div>


<?php
include 'include/footer.php';
?>