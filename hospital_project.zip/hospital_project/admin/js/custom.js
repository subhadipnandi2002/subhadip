
function Shownav(){
	if (document.getElementById('side').style.display == 'block') {
		document.getElementById('side').style.display = ' none';
	}
	else{
		document.getElementById('side').style.display = 'block';
	}
}



function Show(){

	if(document.getElementById('submenu1').style.display == 'block'){
		document.getElementById('submenu1').style.display = 'none';

	}else{
		document.getElementById('submenu1').style.display = 'block';
		document.getElementById('submenu2').style.display = 'none';
		document.getElementById('submenu3').style.display = 'none';
		document.getElementById('submenu4').style.display = 'none';
		document.getElementById('submenu5').style.display = 'none';
		document.getElementById('submenu6').style.display = 'none';
		document.getElementById('submenu7').style.display = 'none';
		document.getElementById('submenu8').style.display = 'none';
	}

}
function Show1(){

	if(document.getElementById('submenu2').style.display == 'block'){
		document.getElementById('submenu2').style.display = 'none';
		document.getElementById("drop2").className = 'fa fa-angle-right';

	}else{
		document.getElementById('submenu2').style.display = 'block';
		document.getElementById("drop2").className = 'fa fa-angle-down';
		document.getElementById('submenu1').style.display = 'none';
		document.getElementById('submenu3').style.display = 'none';
		document.getElementById('submenu4').style.display = 'none';
		document.getElementById('submenu5').style.display = 'none';
		document.getElementById('submenu6').style.display = 'none';
		document.getElementById('submenu7').style.display = 'none';
		document.getElementById('submenu8').style.display = 'none';
	}

}
function Show2(){

	if(document.getElementById('submenu3').style.display == 'block'){
		document.getElementById('submenu3').style.display = 'none';

	}else{
		document.getElementById('submenu3').style.display = 'block';
		document.getElementById('submenu1').style.display = 'none';
		document.getElementById('submenu2').style.display = 'none';
		document.getElementById('submenu4').style.display = 'none';
		document.getElementById('submenu5').style.display = 'none';
		document.getElementById('submenu6').style.display = 'none';
		document.getElementById('submenu7').style.display = 'none';
		document.getElementById('submenu8').style.display = 'none';
	}

}
function Show3(){

	if(document.getElementById('submenu4').style.display == 'block'){
		document.getElementById('submenu4').style.display = 'none';

	}else{
		document.getElementById('submenu4').style.display = 'block';
		document.getElementById('submenu1').style.display = 'none';
		document.getElementById('submenu2').style.display = 'none';
		document.getElementById('submenu3').style.display = 'none';
		document.getElementById('submenu5').style.display = 'none';
		document.getElementById('submenu6').style.display = 'none';
		document.getElementById('submenu7').style.display = 'none';
		document.getElementById('submenu8').style.display = 'none';
	}

}
function Show4(){

	if(document.getElementById('submenu5').style.display == 'block'){
		document.getElementById('submenu5').style.display = 'none';

	}else{
		document.getElementById('submenu5').style.display = 'block';
		document.getElementById('submenu1').style.display = 'none';
		document.getElementById('submenu2').style.display = 'none';
		document.getElementById('submenu3').style.display = 'none';
		document.getElementById('submenu4').style.display = 'none';
		document.getElementById('submenu6').style.display = 'none';
		document.getElementById('submenu7').style.display = 'none';
		document.getElementById('submenu8').style.display = 'none';
	}

}
function Show5(){

	if(document.getElementById('submenu6').style.display == 'block'){
		document.getElementById('submenu6').style.display = 'none';

	}else{
		document.getElementById('submenu6').style.display = 'block';
		document.getElementById('submenu1').style.display = 'none';
		document.getElementById('submenu2').style.display = 'none';
		document.getElementById('submenu3').style.display = 'none';
		document.getElementById('submenu4').style.display = 'none';
		document.getElementById('submenu5').style.display = 'none';
		document.getElementById('submenu7').style.display = 'none';
		document.getElementById('submenu8').style.display = 'none';
	}

}

function Show6(){

	if(document.getElementById('submenu7').style.display == 'block'){
		document.getElementById('submenu7').style.display = 'none';

	}else{
		document.getElementById('submenu7').style.display = 'block';
		document.getElementById('submenu1').style.display = 'none';
		document.getElementById('submenu2').style.display = 'none';
		document.getElementById('submenu3').style.display = 'none';
		document.getElementById('submenu4').style.display = 'none';
		document.getElementById('submenu5').style.display = 'none';
		document.getElementById('submenu6').style.display = 'none';
		document.getElementById('submenu8').style.display = 'none';
	}

}
function Show7(){

	if(document.getElementById('submenu8').style.display == 'block'){
		document.getElementById('submenu8').style.display = 'none';

	}else{
		document.getElementById('submenu8').style.display = 'block';
		document.getElementById('submenu1').style.display = 'none';
		document.getElementById('submenu2').style.display = 'none';
		document.getElementById('submenu3').style.display = 'none';
		document.getElementById('submenu4').style.display = 'none';
		document.getElementById('submenu5').style.display = 'none';
		document.getElementById('submenu6').style.display = 'none';
		document.getElementById('submenu7').style.display = 'none';
	}

}





