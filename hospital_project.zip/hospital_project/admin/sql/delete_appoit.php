<?php

include 'config.php';
$id = $_GET['id'];

$sql = " DELETE FROM   appoint WHERE id = '$id'";

if(mysqli_query($conn,$sql)){
	echo "<script>
        alert('Deleted Details Successfully');
        window.location = 'http://localhost/hospital_project/admin/appointment_view.php';
	</script>";
}else{
	echo "Eror".mysqli_error($conn);
}
 
?>