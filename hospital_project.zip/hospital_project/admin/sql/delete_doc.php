<?php

include 'config.php';
$id = $_GET['id'];

$sql = " DELETE FROM add_doctor WHERE id = '$id'";

if(mysqli_query($conn,$sql)){
	echo "<script>
        alert('Deleted Details Successfully');
        window.location = 'http://localhost/hospital_project/admin/doctor_view.php';
	</script>";
}else{
	echo "Error".mysqli_error($conn);
}
 
?>