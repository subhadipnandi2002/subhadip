<?php

if(isset($_POST['submit'])){

	include 'config.php';


	$sname = $_POST['sname'];
	$experiences_ = $_POST['experiences_'];
	$phone_ = $_POST['phone_'];
	$pic_ = $_FILES['pic_']['name'];

	
	move_uploaded_file($_FILES['pic_']['tmp_name'],'../img/' .$_FILES['pic_']['name']);

	$sql =  "INSERT INTO add_staff(sname,experiences_,phone_,pic_)VALUES('$sname', '$experiences_','$phone_','$pic_')";

	if(mysqli_query($conn,$sql)){
		echo "<script>
				window.location= 'http://localhost/hospital_project/admin/add_staff.php';
		</script>";
	}else{
		echo "error" .mysqli_error($conn);
	}
}

?>
