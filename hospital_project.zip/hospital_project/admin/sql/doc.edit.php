<?php
session_start();

if(isset($_POST['edit'])){
include 'config.php';

$id = $_POST['id'];
$dname = $_POST['dname'];
$experiences = $_POST['experiences'];
$phone = $_POST['phone'];
$pic = $_FILES['pic']['name'];
    


move_uploaded_file($_FILES['pic']['tmp_name'], "../img/".$_FILES['pic']['name']);


$sql = "UPDATE add_doctor SET dname='$dname', experiences='$experiences', phone='$phone' , pic='$pic' WHERE id = '$id'";

if(mysqli_query($conn,$sql)){
    echo "<script>
           alert('Data Successfully updated');
           window.location = 'http://localhost/hospital_project/admin/doctor_view.php';
        </script>";
}else{
    echo "Error".mysqli_error($conn);
}
  }
 
?>