<?php
session_start();

if(isset($_POST['edit'])){
include 'config.php';

$id = $_POST['id'];
$sname = $_POST['sname'];
$experiences_ = $_POST['experiences_'];
$phone_ = $_POST['phone_'];
$pic_ = $_FILES['pic_']['name'];
    


move_uploaded_file($_FILES['pic_']['tmp_name'], "../img/".$_FILES['pic_']['name']);


$sql = "UPDATE add_staff SET sname='$sname', experiences_='$experiences_', phone_='$phone_' , pic_='$pic_' WHERE id = '$id'";

if(mysqli_query($conn,$sql)){
    echo "<script>
           alert('Data Successfully updated');
           window.location = 'http://localhost/hospital_project/admin/staff_view.php';
        </script>";
}else{
    echo "Error".mysqli_error($conn);
}
  }
 
?>