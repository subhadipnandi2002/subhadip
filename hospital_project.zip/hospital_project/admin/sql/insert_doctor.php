<?php

if(isset($_POST['submit'])){

	include 'config.php';


	$dname = $_POST['dname'];
	$experiences = $_POST['experiences'];
	$phone = $_POST['phone'];
	$pic = $_FILES['pic']['name'];

	
	move_uploaded_file($_FILES['pic']['tmp_name'],'../img/' .$_FILES['pic']['name']);

	$sql =  "INSERT INTO add_doctor(dname,experiences,phone,pic)VALUES('$dname', '$experiences','$phone','$pic')";

	if(mysqli_query($conn,$sql)){
		echo "<script>
				window.location= 'http://localhost/hospital_project/admin/add_doctor.php';
		</script>";
	}else{
		echo "error" .mysqli_error($conn);
	}
}

?>
