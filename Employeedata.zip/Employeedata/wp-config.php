<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'db_employeedata' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '#P9|%PmFTi$nfE/F]mlp>-0Kd){2/1Z@1xOl;Min*8m/zqq[JPg#y,&]y.d9E8dK' );
define( 'SECURE_AUTH_KEY',  'keCt<c4+&%7ELllZ+ggE!7r*QH1TiNK^FdJi+s1]j44uD?HxDx DOQ|bJnzPg1R{' );
define( 'LOGGED_IN_KEY',    '_S!]}^?]Z]8UiUo_-1BnN7aY#V&QeUAO2[-ZRb1?NQ(nK _94kmZ+;J}}kt>9Y/1' );
define( 'NONCE_KEY',        '!Trm!=<u`)4>ncbLiVA4R.M9@9r-<o`qAGD}#*4N/hkdAdI)r8`?S!ik]l`qM-a1' );
define( 'AUTH_SALT',        ')T_/swpv)?3k=IR^z%uEy!IyJ<hi.Id0UB#q[2EotW[gxeRB{6TaJMxPB(zs}|uS' );
define( 'SECURE_AUTH_SALT', 'K-Qj|;!)HZIuq]%T!;9Q>RziW]*e0)`e&DOoe]P^<7MZ>m0IL)4(Rf A.F>g$L5q' );
define( 'LOGGED_IN_SALT',   'cS8WQmF%4_HH}0R@5MLEBwQbY*2#jMt;&=KC2QhCITu5Ca!Hli+hX$q{K?~OVql6' );
define( 'NONCE_SALT',       '5LQzJ#w,~IB96[Oh>+u^0ay;7QZ*DBK[GmD8MzKDqS.6~maG%be;dZ$HCyjk^)F?' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
