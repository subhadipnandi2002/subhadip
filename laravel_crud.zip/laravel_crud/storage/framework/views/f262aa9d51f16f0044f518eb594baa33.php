<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Student</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous">
    </script>
    <link rel="stylesheet" href="<?php echo e(url('style.css')); ?>">
</head>

<body>
    <div class="container mt-5">
        <div class="row">

            <form class="col-md-12" action="<?php echo e($currentUserEdit->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <h3 class="alert alert-warning text-center">Edit Student</h3>

                <div>
                    <label for="nameid" class="form-label">Name</label>
                    <input type="text" class="form-control" id="nameid" name="name" value="<?php echo e($currentUserEdit->name); ?>">
                </div>

                <div>
                    <label for="emailid" class="form-label">Email</label>
                    <input type="email" class="form-control" id="emailid" name="email" value="<?php echo e($currentUserEdit->email); ?>">
                </div>

                <div>
                    <label for="passwordid" class="form-label">Password</label>
                    <input type="text" class="form-control" id="passwordid" name="password" value="<?php echo e($currentUserEdit->password); ?>">
                </div>

                <div class="mt-3">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>

        </div>
    </div>

    <script src="<?php echo e(url('custom.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel_crud\resources\views/edit.blade.php ENDPATH**/ ?>