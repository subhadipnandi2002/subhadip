<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StudentController extends Controller
{
    public function viewStudentPage(){
        $students = Student::all();

        return view('student', compact('students'));
    }


    public function addStudent(Request $request){

        DB::table('students')
            ->insert([
                'name' => $request->input('name'),
                'email' => $request->input('email'),
                'password' => $request->input('password')
            ]);


        return redirect('/')->with('success', 'Student Added Successfully');
    }


    public function editPage(string $id){
        
        $currentUserEdit = Student::where('id',$id)->first();
            

        return view('edit', compact('currentUserEdit'));   
    }

    public function editStudent(Request $request, string $id){
        Student::where('id', $id)
            ->update([
                'name' => $request->name,
                'email' => $request->email,
                'password' => $request->password
            ]);
        
        return redirect('/')->with('success', 'Student Updated Successfully');
    }



    public function deleteStudent(string $id){
        Student::where('id',$id)->delete();

        return redirect('/')->with('success','Student Deleted Successfully');
    }
}
