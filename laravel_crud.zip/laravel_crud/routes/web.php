<?php

use App\Http\Controllers\StudentController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [StudentController::class, 'viewStudentPage']);

Route::post('/', [StudentController::class, 'addStudent']);

Route::get('edit/{id}', [StudentController::class, 'editPage']);

Route::post('edit/{id}', [StudentController::class, 'editStudent']);

Route::get('delete/{id}', [StudentController::class, 'deleteStudent']);
